<?php
  $host = 'localhost'; // адрес сервера 127.0.0.1:3306
  $database = 'zhenya_todorov'; // имя базы данных
  $user = 'dari'; // имя пользователя
  $password = 'Zxcvbnm123'; // пароль
?>