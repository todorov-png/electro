'use strict';


function toJsonee(parentSelector, name, id, price, src, direction, socket, bios, ramFormFactor, sound, powerPlug, formFactor, chipset, ramSlot, ramFrequency, plugs, processorPower, description) {

  const datam = {
    'parentSelector' : parentSelector,
    'name' : name,
    'id' : id,
    'price' : price,
    'src' : src,
    'direction' : direction,
    'socket' : socket,
    'bios' : bios,
    'ramFormFactor' : ramFormFactor,
    'sound' : sound,
    'powerPlug' : powerPlug,
    'formFactor' : formFactor,
    'chipset' : chipset,
    'ramSlot' : ramSlot,
    'ramFrequency' : ramFrequency,
    'plugs' : plugs,
    'processorPower' : processorPower,
    'description' : description,
    


    'size' : '305x235 мм',
    'slotsRAM' : '4 слота',
    'modeRAM' : '2-х канальный',
    'amountRAM' : '64 ГБ',
    'supportXMP' : '+',
    'outputHDMI' : '+',
    'outputDVI' : 'DVI-D',
    'audioChip' : 'Realtek ALC892',
    'LAN' : '1 Гбит/с',
    'quantityLAN' : '1 шт',
    'controllerLAN' : 'Realtek GbE',
    'slotsPCIE1x' : '2 шт',
    'slotsPCIE16x' : '2 шт',
    'supportExpress' : '3.0',
    'supportCrossFire' : '+',
    'USB2' : '4 шт',
    'USB3' : '4 шт',
    'PS2' : '1 шт',
    'coolerPower' : '4 шт',
  }
  console.log(JSON.stringify(datam))
}

toJsonee('.wrapper', 'Gigabyte B450 AORUS ELITE rev. 1.0', 'mb001', 2800, '/images/GIGABYTE-B450-AORUS-ELITE-REV--1-0.jpg', 'геймерская', 'AMD AM4', 'Ami', 'DIMM', '7.1', '24-контактный', 'ATX', 'AMD B450', 'DDR4', '3600 МГц', 'HDMI, M.2', '8-контактное', 'Наиболее хорошо оснащенная и функциональная материнская плата Gigabyte на основе набора системной логики AMD B450 с процессорным разъемом АМ4. Относится к семейству AORUS, включающем в себя игровые модели материнских плат. Позиционируется как продукт средней ценовой категории, совместима с CPU AMD Zen, а именно с моделями: Ryzen 3, 5, 7 (Pro) 1-го и 2-го поколения на ядрах Summit Ridge, Pinnacle Ridge, Raven Ridge и CPU Athlon 200GE (Pro). Имеет габариты соответствующие стандарту АТХ, предназначена для сборки высокопроизводительных домашних и игровых систем. Отличается использованием высокотехнологичной цифровой подсистемы питания Hybrid Digital PWM (8+3 фазы) и наличием специального радиатора Thermal Guard для отвода тепла от высокопроизводительного NVMe SSD-накопителя, подключаемого к первому порту М.2. Материнская плата Gigabyte B450 AORUS Elite поддерживает установку до 4-х модулей оперативной памяти с суммарным объемом до 64 Гб, чего достаточно для любых игр и приложений. Кроме двух портов М.2 она оборудована 6-ю разъемами SATA3 для SSD/HDD-дисков, интегрированным гигабитным сетевым контроллером Realtek и восьмиканальным аудиокодеком Realtek ALC892 с улучшенным аналоговым трактом. Подключение периферийных устройств возможно к 11 USB-портам, среди которых имеется 4 высокоскоростных разъемов USB 3.1 Gen1 (до 5 Гбит/с). Плата оборудована светодиодной подсветкой и поддерживает технологию ее синхронизации Gigabyte RGB Fusion.')




/* size, slotsRAM, modeRAM, amountRAM, supportXMP, outputHDMI, outputDVI, audioChip, LAN, quantityLAN, controllerLAN, slotsPCIE1x, slotsPCIE16x, supportExpress, supportCrossFire, USB2, USB3, PS2, coolerPower */



//Вторая плата
const datam2 = {
  'parentSelector' : '.wrapper',
  'name' : 'Asus Maximus IX Apex',
  'id' : 'mb002',
  'price' : 5800,
  'src' : '/images/mb002.jpg',
  'direction' : 'геймерская',
  'socket' : 'Intel LGA 1151',
  'bios' : 'Ami',
  'ramFormFactor' : 'DIMM',
  'sound' : '7.1',
  'powerPlug' : '24-контактный',
  'formFactor' : 'E-ATX',
  'chipset' : 'Intel Z270',
  'ramSlot' : 'DDR4',
  'ramFrequency' : '4266 МГц',
  'plugs' : 'HDMI, M.2',
  'processorPower' :  '8+8-контактное',
  'description' : 'Оснащена разъемом DIMM.2 для подключения M.2 SSD накопителей через комплектный адаптер. Кнопки очистки CMOS-памяти и обновления BIOS на задней панели.',
  'size' : '305x272 мм',
  'slotsRAM' : '2 слота',
  'modeRAM' : '2-х канальный',
  'amountRAM' : '32 ГБ',
  'supportXMP' : '+',
  'outputHDMI' : '+',
  'outputDVI' : '-',
  'audioChip' : 'SupremeFX',
  'LAN' : '1 Гбит/с',
  'quantityLAN' : '1 шт',
  'controllerLAN' : 'Intel I219V',
  'slotsPCIE1x' : '2 шт',
  'slotsPCIE16x' : '1 шт',
  'supportExpress' : '3.0',
  'supportCrossFire' : '+',
  'USB2' : '-',
  'USB3' : '7 шт',
  'PS2' : '2 шт',
  'coolerPower' : '5 шт',
};


console.log(JSON.stringify(datam2));

//Третья плата
const datam3 = {
  'parentSelector' : '.wrapper',
  'name' : 'MSI B85M-E45',
  'id' : 'mb003',
  'price' : 1795,
  'src' : '/images/mb003.jpg',
  'direction' : 'для дома / офиса',
  'socket' : 'Intel LGA 1150',
  'bios' : 'Ami',
  'ramFormFactor' : 'DIMM',
  'sound' : '7.1',
  'powerPlug' : '24-контактный',
  'formFactor' : 'micro-ATX',
  'chipset' : 'Intel B85',
  'ramSlot' : 'DDR3',
  'ramFrequency' : '1600 МГц',
  'plugs' : 'HDMI',
  'processorPower' :  '4-контактное',
  'description' : 'MSI B85M-E45 материнская плата, которая поддерживает четвертое поколение процессоров Intel Core i7, i5 и i3, а также Pentium и Celeron, содержат интегрированные контроллеры памяти и шины PCI Express.',
  'size' : '228х244 мм',
  'slotsRAM' : '4 слота',
  'modeRAM' : '2-х канальный',
  'amountRAM' : '32 ГБ',
  'supportXMP' : '+',
  'outputHDMI' : '+',
  'outputDVI' : 'DVI-D',
  'audioChip' : 'Realtek ALC887',
  'LAN' : '1 Гбит/с',
  'quantityLAN' : '1 шт',
  'controllerLAN' : 'Realtek 8111G',
  'slotsPCIE1x' : '2 шт',
  'slotsPCIE16x' : '1 шт',
  'supportExpress' : '3.0',
  'supportCrossFire' : '-',
  'USB2' : '4 шт',
  'USB3' : '2 шт',
  'PS2' : '2 шт',
  'coolerPower' : '3 шт',
}
console.log(JSON.stringify(datam3));

console.log([datam2, datam3].reduce((txt, item) => txt + '<td>'+item.socket+'</td>', ''));


//Оперативная память 1
const datam4 = {
    'parentSelector' : '.wrapper',
    'name' : 'G.Skill Aegis DDR4 2x8Gb',
    'id' : 'rm001',
    'price' : 3150,
    'src' : '/images/rm001.jpg',
    'ramKit' : '16 ГБ',
    'counterStripts' : '2 шт',
    'ramFormFactor' : 'DIMM',
    'ramSlot' : 'DDR4',
    'ramFrequency' : '3200 МГц',
    'bandwidth' : '25600 МБ/с',
    'timingScheme' : '16-18-18-38',
    'voltage' : '1.35 В',
    'coolingType' : 'без охлаждения',
    'plankProfile' : 'стандартный',
    'heightPlank' : '31.2 мм'
}
console.log(JSON.stringify(datam4))

//Оперативная память 2
const datam5 = {
  'parentSelector' : '.wrapper',
  'name' : 'Crucial Ballistix RGB DDR4 2x8Gb',
  'id' : 'rm002',
  'price' : 3780,
  'src' : '/images/rm002.jpg',
  'ramKit' : '16 ГБ',
  'counterStripts' : '2 шт',
  'ramFormFactor' : 'DIMM',
  'ramSlot' : 'DDR4',
  'ramFrequency' : '3200 МГц',
  'bandwidth' : '25600 МБ/с',
  'timingScheme' : '16-18-18-38',
  'voltage' : '1.35 В',
  'coolingType' : 'радиатор',
  'plankProfile' : 'стандартный',
  'heightPlank' : '39.2 мм'
}
console.log(JSON.stringify(datam5))

//Оперативная память 3
const datam6 = {
  'parentSelector' : '.wrapper',
  'name' : 'G.Skill Trident Z DDR4 2x16Gb',
  'id' : 'rm003',
  'price' : 8905,
  'src' : '/images/rm003.jpg',
  'ramKit' : '32 ГБ',
  'counterStripts' : '2 шт',
  'ramFormFactor' : 'DIMM',
  'ramSlot' : 'DDR4',
  'ramFrequency' : '3600 МГц',
  'bandwidth' : '28800 МБ/с',
  'timingScheme' : '17-19-19-39',
  'voltage' : '1.35 В',
  'coolingType' : 'радиатор',
  'plankProfile' : 'стандартный',
  'heightPlank' : '44 мм'
}
console.log(JSON.stringify(datam6))



//Оперативная память 4
const datam7 = {
  'parentSelector' : '.wrapper',
  'name' : 'HyperX Fury DDR3 2x8Gb',
  'id' : 'rm004',
  'price' : 4170,
  'src' : '/images/rm004.jpg',
  'ramKit' : '16 ГБ',
  'counterStripts' : '2 шт',
  'ramFormFactor' : 'DIMM',
  'ramSlot' : 'DDR3',
  'ramFrequency' : '1600 МГц',
  'bandwidth' : '12800 МБ/с',
  'timingScheme' : '10-10-10-30',
  'voltage' : '1.5 В',
  'coolingType' : 'радиатор',
  'plankProfile' : 'стандартный',
  'heightPlank' : '32.8 мм'
}
console.log(JSON.stringify(datam7))

//Оперативная память 5
const datam8 = {
  'parentSelector' : '.wrapper',
  'name' : 'G.Skill Ares DDR3 2x4Gb',
  'id' : 'rm005',
  'price' : 1300,
  'src' : '/images/rm005.jpg',
  'ramKit' : '8 ГБ',
  'counterStripts' : '2 шт',
  'ramFormFactor' : 'DIMM',
  'ramSlot' : 'DDR3',
  'ramFrequency' : '1600 МГц',
  'bandwidth' : '12800 МБ/с',
  'timingScheme' : '9-9-9',
  'voltage' : '1.5 В',
  'coolingType' : 'радиатор',
  'plankProfile' : 'стандартный',
  'heightPlank' : '32.8 мм'
}
console.log(JSON.stringify(datam8))


//Процессор 1
const datam9 = {
  'parentSelector' : '.wrapper',
  'name' : 'AMD Ryzen 3 Summit Ridge 1200 BOX 12 nm',
  'id' : 'cp001',
  'price' : 2980,
  'src' : '/images/cp001.jpg',

  'series' : 'Ryzen 3',
  'socket' : 'AMD AM4',
  'numberCores' : '4 cores',
  'numberThreads' : '4 threads',
  'clockFrequency' : '3.1 ГГц',
  'turboBoost' : '3.4 ГГц',
  'technicalProcess' : '12 нм',
  'IGP' : 'отсутствует',

  'levelVolume1' : '384 КБ',
  'levelVolume2' : '2048 КБ',
  'levelVolume3' : '8 МБ',

  'TDP' : '65 Вт',
  'multiplier' : '31',
  'freeMultiplier' : '+',
  'maxTemperature' : '95 °С',

  'maxVolume' : '64 ГБ',
  'maxFrequency' : '2667 МГц',
  'numberChannels' : '2 шт'
}
console.log(JSON.stringify(datam9))


//Процессор 2
console.log(JSON.stringify({
  'parentSelector' : '.wrapper',
  'name' : 'AMD Ryzen 3 Picasso 3200G MPK',
  'id' : 'cp002',
  'price' : 4760,
  'src' : '/images/cp002.jpg',

  'series' : 'Ryzen 3',
  'socket' : 'AMD AM4',
  'numberCores' : '4 cores',
  'numberThreads' : '4 threads',
  'clockFrequency' : '3.6 ГГц',
  'turboBoost' : '4 ГГц',
  'technicalProcess' : '12 нм',
  'IGP' : 'Radeon Vega 8',

  'levelVolume1' : '384 КБ',
  'levelVolume2' : '2048 КБ',
  'levelVolume3' : '4 МБ',

  'TDP' : '65 Вт',
  'multiplier' : '36',
  'freeMultiplier' : '+',
  'maxTemperature' : '95 °С',

  'maxVolume' : '64 ГБ',
  'maxFrequency' : '2933 МГц',
  'numberChannels' : '2 шт'
}))


//Процессор 3
console.log(JSON.stringify({
  'parentSelector' : '.wrapper',
  'name' : 'Intel Core i7 Skylake i7-6700T OEM',
  'id' : 'cp003',
  'price' : 12890,
  'src' : '/images/cp003.jpg',

  'series' : 'Core i7',
  'socket' : 'Intel LGA 1151',
  'numberCores' : '4 cores',
  'numberThreads' : '8 threads',
  'clockFrequency' : '2.8 ГГц',
  'turboBoost' : '3.6 ГГц',
  'technicalProcess' : '14 нм',
  'IGP' : 'HD Graphics 530',

  'levelVolume1' : '256 КБ',
  'levelVolume2' : '1024 КБ',
  'levelVolume3' : '8 МБ',

  'TDP' : '35 Вт',
  'multiplier' : '28',
  'freeMultiplier' : '-',
  'maxTemperature' : '66 °С',

  'maxVolume' : '64 ГБ',
  'maxFrequency' : '2133 МГц',
  'numberChannels' : '2 шт'
}))

//Процессор 4
console.log(JSON.stringify({
  'parentSelector' : '.wrapper',
  'name' : 'Intel Core i5 Kaby Lake i5-7400 BOX',
  'id' : 'cp004',
  'price' : 7280,
  'src' : '/images/cp004.jpg',

  'series' : 'Core i5',
  'socket' : 'Intel LGA 1151',
  'numberCores' : '4 cores',
  'numberThreads' : '4 threads',
  'clockFrequency' : '3 ГГц',
  'turboBoost' : '3.5 ГГц',
  'technicalProcess' : '14 нм',
  'IGP' : 'HD Graphics 630',

  'levelVolume1' : '256 КБ',
  'levelVolume2' : '1024 КБ',
  'levelVolume3' : '6 МБ',

  'TDP' : '65 Вт',
  'multiplier' : '30',
  'freeMultiplier' : '-',
  'maxTemperature' : '100 °С',

  'maxVolume' : '64 ГБ',
  'maxFrequency' : '2400 МГц',
  'numberChannels' : '2 шт'
}))


//Процессор 5
console.log(JSON.stringify({
  'parentSelector' : '.wrapper',
  'name' : 'Intel Core i5 Devils Canyon i5-4690K',
  'id' : 'cp005',
  'price' : 3865,
  'src' : '/images/cp005.jpg',

  'series' : 'Core i5',
  'socket' : 'Intel LGA 1150',
  'numberCores' : '4 cores',
  'numberThreads' : '4 threads',
  'clockFrequency' : '3.5 ГГц',
  'turboBoost' : '3.9 ГГц',
  'technicalProcess' : '22 нм',
  'IGP' : 'HD Graphics 4600',

  'levelVolume1' : '128 КБ',
  'levelVolume2' : '1024 КБ',
  'levelVolume3' : '6 МБ',

  'TDP' : '88 Вт',
  'multiplier' : '35',
  'freeMultiplier' : '+',
  'maxTemperature' : '73 °С',

  'maxVolume' : '32 ГБ',
  'maxFrequency' : '1600 МГц',
  'numberChannels' : '2 шт'
}))




//Процессор 6
console.log(JSON.stringify({
  'parentSelector' : '.wrapper',
  'name' : 'Intel Core i3 Haswell i3-4150 OEM',
  'id' : 'cp006',
  'price' : 2400,
  'src' : '/images/cp006.jpg',

  'series' : 'Core i3',
  'socket' : 'Intel LGA 1150',
  'numberCores' : '2 cores',
  'numberThreads' : '4 threads',
  'clockFrequency' : '3.5 ГГц',
  'turboBoost' : '-',
  'technicalProcess' : '22 нм',
  'IGP' : 'HD Graphics 4400',

  'levelVolume1' : '64 КБ',
  'levelVolume2' : '512 КБ',
  'levelVolume3' : '3 МБ',

  'TDP' : '54 Вт',
  'multiplier' : '35',
  'freeMultiplier' : '-',
  'maxTemperature' : '72 °С',

  'maxVolume' : '32 ГБ',
  'maxFrequency' : '1600 МГц',
  'numberChannels' : '2 шт'
}))


//Процессор 7
console.log(JSON.stringify({
  'parentSelector' : '.wrapper',
  'name' : 'Intel Xeon E3 v3 E3-1220 v3',
  'id' : 'cp007',
  'price' : 1790,
  'src' : '/images/cp007.jpg',

  'series' : 'Xeon',
  'socket' : 'Intel LGA 1150',
  'numberCores' : '4 cores',
  'numberThreads' : '4 threads',
  'clockFrequency' : '3.1 ГГц',
  'turboBoost' : '3.5 ГГц',
  'technicalProcess' : '22 нм',
  'IGP' : 'отсутствует',

  'levelVolume1' : '256 КБ',
  'levelVolume2' : '1024 КБ',
  'levelVolume3' : '8 МБ',

  'TDP' : '80 Вт',
  'multiplier' : '30',
  'freeMultiplier' : '-',
  'maxTemperature' : '100 °С',

  'maxVolume' : '32 ГБ',
  'maxFrequency' : '1600 МГц',
  'numberChannels' : '2 шт'
}))

//Видеокарта 1
console.log(JSON.stringify({
  'parentSelector' : '.wrapper',
  'name' : 'Palit GeForce GT 710 NEAT7100HD46-2080H',
  'id' : 'gc001',
  'price' : 2510,
  'src' : '/images/gc001.jpg',

  'versionPCI' : '2.0',

  'modelGPU' : 'NVIDIA GeForce GT 710',
  'memoryCapacity' : '2 ГБ',
  'memoryType' : 'DDR3',
  'busWidth' : '64 бит',
  'frequencyGPU' : '954 МГц',
  'frequencyRAM' : '1600 МГц',
  'technicalProcess' : '28 нм',
  'maxResolution' : '2560x1600 пикс',

  'connectorVGA' : '1 шт',
  'connectorDVI' : '1 шт',
  'connectorHDMI' : '1 шт',

  'versionDirectX' : '12',
  'versionOpenGL' : '4.5',
  'streamProcessors' : '192',
  'streamProcessorsVersion' : '5',
  'textureBlocks' : '16',

  'connectedMonitors' : '2',
  'cooling' : 'пассивное (радиатор)',
  'occupiedSlots' : '1',
  'lowProfile' : '+',
  'length' : '115 мм',
  'description' : 'Компания Palit Microsystems Ltd, ведущий производитель графических процессоров, представляет видеокарту Palit GeForce GT 710. Новинка ускорит выполнение задач, требовательных к графической подсистеме, до 10 раз по сравнению с интегрированной графикой — интернет-браузер, графические редакторы и игры будут работать намного быстрее.'
}))


//Видеокарта 2
console.log(JSON.stringify({
  'parentSelector' : '.wrapper',
  'name' : 'Gigabyte GeForce GT 710 GV-N710D5SL-2GL',
  'id' : 'gc002',
  'price' : 3100,
  'src' : '/images/gc002.jpg',

  'versionPCI' : '2.0',

  'modelGPU' : 'NVIDIA GeForce GT 710',
  'memoryCapacity' : '2 ГБ',
  'memoryType' : 'GDDR5',
  'busWidth' : '32 бит',
  'frequencyGPU' : '954 МГц',
  'frequencyRAM' : '5010 МГц',
  'technicalProcess' : '28 нм',
  'maxResolution' : '4096x2160 пикс',

  'connectorVGA' : '-',
  'connectorDVI' : '1 шт',
  'connectorHDMI' : '1 шт',

  'versionDirectX' : '12',
  'versionOpenGL' : '4.5',
  'streamProcessors' : '192',
  'streamProcessorsVersion' : '5',
  'textureBlocks' : '16',

  'connectedMonitors' : '2',
  'cooling' : 'пассивное (радиатор)',
  'occupiedSlots' : '1',
  'lowProfile' : '+',
  'length' : '151 мм',
  'description' : 'Низкопрофильная сверхмалогабаритная видеокарта начального уровня с радиатором пассивного охлаждения и подключением по интерфейсу PCI-E v2.0 x8. Имеет весьма доступную стоимость, поддерживает вывод изображения с 4К-разрешением и двухмониторные конфигурации. Изготовлена в соответствии с фирменной концепцией Ultra Durable 2 предполагающей использование улучшенного текстолита и элементной базы повышенной надежности (корпусные ферритовые дроссели, Low RDS MOSFET, долговечные твердотельные конденсаторы). Малая ширина (low profile) и короткая печатная плата (151 мм) позволяют устанавливать видеокарту Gigabyte GeForce GT 710 GV-N710D5SL-2GL в практически любые корпуса форматов ATX (стандарт полного размера), microATX (компактные корпуса) и miniITX (сверхкомпактные корпуса). Производителем позиционируется как доступное устройство для комплектации домашних и офисных персональных компьютеров, оснащенных процессорами лишенными встроенного видеоядра. Оборудована GPU GK208, изготовленного по 28 нм технологическому процессу (192 CUDA-процессора, 16 текстурных блоков и 8 блоков растровых операций). Объем графической памяти GDDR5 равен 2 Гб при шине 32 бита. Видеокарта обеспечивает базовый уровень 3D-производительности, которого достаточно для поддержания комфортной частоты смены кадров в популярных игровых проектах 2013-2017 годов при разрешении 1920х1080 и низких/средне-низких настройках качества графики. Для вывода изображения предусмотрен цифровой порт HDMI и гибридный Dual-Link DVI-I.'
}))


//Видеокарта 3
console.log(JSON.stringify({
  'parentSelector' : '.wrapper',
  'name' : 'Gigabyte GeForce GT 710 GV-N710D3-2GL',
  'id' : 'gc003',
  'price' : 2700,
  'src' : '/images/gc003.jpg',

  'versionPCI' : '2.0',

  'modelGPU' : 'NVIDIA GeForce GT 710',
  'memoryCapacity' : '2 ГБ',
  'memoryType' : 'DDR3',
  'busWidth' : '64 бит',
  'frequencyGPU' : '954 МГц',
  'frequencyRAM' : '1800 МГц',
  'technicalProcess' : '28 нм',
  'maxResolution' : '	4096x2160 пикс',

  'connectorVGA' : '1 шт',
  'connectorDVI' : '1 шт',
  'connectorHDMI' : '1 шт',

  'versionDirectX' : '12',
  'versionOpenGL' : '4.5',
  'streamProcessors' : '192',
  'streamProcessorsVersion' : '5',
  'textureBlocks' : '16',

  'connectedMonitors' : '2',
  'cooling' : 'активное (кулер)',
  'occupiedSlots' : '1',
  'lowProfile' : '+',
  'length' : '144 мм',
  'description' : 'Ультракомпактная низкопрофильная видеокарта начальной ценовой категории с однослотовой системой активного охлаждения, интерфейсом подключения к материнской плате PCI-E 2.0 х8 и возможностью вывода изображения с разрешением до 3840х2160. Отличается доступной стоимостью, использованием высококачественных компонентов согласно фирменной концепции Ultra Durable 2, тихой работой и поддержкой двухмониторных конфигураций. Скромные габаритные размеры (144х68х21 мм) и наличие в комплекте низкопрофильной установочной планки позволяет использовать эту карту в сверхкомпактных корпусах формата mini-ITX. Производителем позиционируется как бюджетное устройство для комплектации домашних и офисных персональных компьютеров, оснащенных процессорами без встроенного видеоядра. Оснащается графическим процессором Nvidia Kepler GK208, изготовленного по 28 нм технологическому процессу и включающему в себя 192 ядра CUDA, 16 текстурных блоков и 8 блоков растровых операций. Такая конфигурация обеспечивает начальный уровень 3D-производительности, который достаточен для не слишком требовательных игр 2013-2016 годов при разрешении до 1920х1080 и низких настройках качества графики. Поддерживаются API DirectX 12 и Open GL 4.5. Для вывода изображения предусмотрены порты VGA D-sub, HDMI и DVI-D.'
}))

//Видеокарта 4
console.log(JSON.stringify({
  'parentSelector' : '.wrapper',
  'name' : 'Gigabyte GeForce GT 1030 Low Profile D4 2G',
  'id' : 'gc004',
  'price' : 3340,
  'src' : '/images/gc004.jpg',

  'versionPCI' : '3.0',

  'modelGPU' : 'NVIDIA GeForce GT 1030',
  'memoryCapacity' : '2 ГБ',
  'memoryType' : 'DDR4',
  'busWidth' : '64 бит',
  'frequencyGPU' : '1177 МГц',
  'frequencyRAM' : '2100 МГц',
  'technicalProcess' : '14 нм',
  'maxResolution' : '4096x2160 пикс',

  'connectorVGA' : '-',
  'connectorDVI' : '1 шт',
  'connectorHDMI' : '1 шт',

  'versionDirectX' : '12',
  'versionOpenGL' : '4.5',
  'streamProcessors' : '384',
  'streamProcessorsVersion' : '5',
  'textureBlocks' : '24',

  'connectedMonitors' : '2',
  'cooling' : 'активное (кулер)',
  'occupiedSlots' : '1',
  'lowProfile' : '+',
  'length' : '150 мм',
  'description' : 'Низкопрофильная видеокарта начальной ценовой категории с поддержкой мониторов UltraHD-разрешения (3840х2160) и низким энергопотреблением. Производителем позиционируется как бюджетный продукт предназначенный для бюджетных ПК и компактных мультимедийных систем класса Home Theatre Personal Computer (HTPC). Имеет сверхмалые габаритные размеры (15х6,9х1,5 см), однослотовую активную систему охлаждения, комплектуется низкопрофильной планкой для установки в малогабаритные корпуса формата mini-ITX. Графический процессор Nvidia Pascal GP108 содержит в своем составе 384 потоковых процессора, 24 текстурных и 16 блоков растровых операций. Он работает в связке с 2 Гб памяти DDR4 с 64 битным интерфейсом. Благодаря такому оснащению видеокарта Gigabyte GeForce GT 1030 GV-N1030D4-2GL показывает базовый уровень игровой 3D-производительности и способна обеспечить приемлемый фреймрейт в большинстве популярных игровых проектов 2015-2017 годов при разрешении до 1920х1080 и низко-средних настройках качества графики. Кроме этого поддерживается аппаратное декодирование мультимедийного контента FullHD и 4К-разрешения, освобождающее ресурсы центрального процессора. Карта оборудована интерфейсными портами Dual-Link DVI и HDMI 2.0b (до 4096х2160 при 60 Гц).'
}))

let id = 'br002';
id = id.slice(0, 2)+'/'+id.slice(2)
console.log(id)