'use strict',


function toJsonee(parentSelector, name, id, price, src, direction, socket, bios, ramFormFactor, sound, powerPlug, formFactor, chipset, ramSlot, ramFrequency, plugs, processorPower, description) {

  const datam = {
    'parentSelector' : parentSelector,
    'name' : name,
    'id' : id,
    'price' : price,
    'src' : src,
    'direction' : direction,
    'socket' : socket,
    'bios' : bios,
    'ramFormFactor' : ramFormFactor,
    'sound' : sound,
    'powerPlug' : powerPlug,
    'formFactor' : formFactor,
    'chipset' : chipset,
    'ramSlot' : ramSlot,
    'ramFrequency' : ramFrequency,
    'plugs' : plugs,
    'processorPower' : processorPower,
    'description' : description,
    


    'size' : '305x235 мм',
    'slotsRAM' : '4 слота',
    'modeRAM' : '2-х канальный',
    'amountRAM' : '64 ГБ',
    'supportXMP' : '+',
    'outputHDMI' : '+',
    'outputDVI' : 'DVI-D',
    'audioChip' : 'Realtek ALC892',
    'LAN' : '1 Гбит/с',
    'quantityLAN' : '1 шт',
    'controllerLAN' : 'Realtek GbE',
    'slotsPCIE1x' : '2 шт',
    'slotsPCIE16x' : '2 шт',
    'supportExpress' : '3.0',
    'supportCrossFire' : '+',
    'USB2' : '4 шт',
    'USB3' : '4 шт',
    'PS2' : '1 шт',
    'coolerPower' : '4 шт',
  };
  console.log(JSON.stringify(datam));
}

toJsonee('.wrapper', 'Gigabyte B450 AORUS ELITE rev. 1.0', 'mb001', 2800, '/images/GIGABYTE-B450-AORUS-ELITE-REV--1-0.jpg', 'геймерская', 'AMD AM4', 'Ami', 'DIMM', '7.1', '24-контактный', 'ATX', 'AMD B450', 'DDR4', '3600 МГц', 'HDMI, M.2', '8-контактное', 'Наиболее хорошо оснащенная и функциональная материнская плата Gigabyte на основе набора системной логики AMD B450 с процессорным разъемом АМ4. Относится к семейству AORUS, включающем в себя игровые модели материнских плат. Позиционируется как продукт средней ценовой категории, совместима с CPU AMD Zen, а именно с моделями: Ryzen 3, 5, 7 (Pro) 1-го и 2-го поколения на ядрах Summit Ridge, Pinnacle Ridge, Raven Ridge и CPU Athlon 200GE (Pro). Имеет габариты соответствующие стандарту АТХ, предназначена для сборки высокопроизводительных домашних и игровых систем. Отличается использованием высокотехнологичной цифровой подсистемы питания Hybrid Digital PWM (8+3 фазы) и наличием специального радиатора Thermal Guard для отвода тепла от высокопроизводительного NVMe SSD-накопителя, подключаемого к первому порту М.2. Материнская плата Gigabyte B450 AORUS Elite поддерживает установку до 4-х модулей оперативной памяти с суммарным объемом до 64 Гб, чего достаточно для любых игр и приложений. Кроме двух портов М.2 она оборудована 6-ю разъемами SATA3 для SSD/HDD-дисков, интегрированным гигабитным сетевым контроллером Realtek и восьмиканальным аудиокодеком Realtek ALC892 с улучшенным аналоговым трактом. Подключение периферийных устройств возможно к 11 USB-портам, среди которых имеется 4 высокоскоростных разъемов USB 3.1 Gen1 (до 5 Гбит/с). Плата оборудована светодиодной подсветкой и поддерживает технологию ее синхронизации Gigabyte RGB Fusion.');




/* size, slotsRAM, modeRAM, amountRAM, supportXMP, outputHDMI, outputDVI, audioChip, LAN, quantityLAN, controllerLAN, slotsPCIE1x, slotsPCIE16x, supportExpress, supportCrossFire, USB2, USB3, PS2, coolerPower */



//Вторая плата
const datam2 = {
  'parentSelector' : '.wrapper',
  'name' : 'Asus Maximus IX Apex',
  'id' : 'mb002',
  'price' : 5800,
  'src' : '/images/mb002.jpg',
  'direction' : 'геймерская',
  'socket' : 'Intel LGA 1151',
  'bios' : 'Ami',
  'ramFormFactor' : 'DIMM',
  'sound' : '7.1',
  'powerPlug' : '24-контактный',
  'formFactor' : 'E-ATX',
  'chipset' : 'Intel Z270',
  'ramSlot' : 'DDR4',
  'ramFrequency' : '4266 МГц',
  'plugs' : 'HDMI, M.2',
  'processorPower' :  '8+8-контактное',
  'description' : 'Оснащена разъемом DIMM.2 для подключения M.2 SSD накопителей через комплектный адаптер. Кнопки очистки CMOS-памяти и обновления BIOS на задней панели.',
  'size' : '305x272 мм',
  'slotsRAM' : '2 слота',
  'modeRAM' : '2-х канальный',
  'amountRAM' : '32 ГБ',
  'supportXMP' : '+',
  'outputHDMI' : '+',
  'outputDVI' : '-',
  'audioChip' : 'SupremeFX',
  'LAN' : '1 Гбит/с',
  'quantityLAN' : '1 шт',
  'controllerLAN' : 'Intel I219V',
  'slotsPCIE1x' : '2 шт',
  'slotsPCIE16x' : '1 шт',
  'supportExpress' : '3.0',
  'supportCrossFire' : '+',
  'USB2' : '-',
  'USB3' : '7 шт',
  'PS2' : '2 шт',
  'coolerPower' : '5 шт',
};
console.log(JSON.stringify(datam2));

//Третья плата
const datam3 = {
  'parentSelector' : '.wrapper',
  'name' : 'MSI B85M-E45',
  'id' : 'mb003',
  'price' : 1795,
  'src' : '/images/mb003.jpg',
  'direction' : 'для дома / офиса',
  'socket' : 'Intel LGA 1150',
  'bios' : 'Ami',
  'ramFormFactor' : 'DIMM',
  'sound' : '7.1',
  'powerPlug' : '24-контактный',
  'formFactor' : 'micro-ATX',
  'chipset' : 'Intel B85',
  'ramSlot' : 'DDR3',
  'ramFrequency' : '1600 МГц',
  'plugs' : 'HDMI',
  'processorPower' :  '4-контактное',
  'description' : 'MSI B85M-E45 материнская плата, которая поддерживает четвертое поколение процессоров Intel Core i7, i5 и i3, а также Pentium и Celeron, содержат интегрированные контроллеры памяти и шины PCI Express.',
  'size' : '228х244 мм',
  'slotsRAM' : '4 слота',
  'modeRAM' : '2-х канальный',
  'amountRAM' : '32 ГБ',
  'supportXMP' : '+',
  'outputHDMI' : '+',
  'outputDVI' : 'DVI-D',
  'audioChip' : 'Realtek ALC887',
  'LAN' : '1 Гбит/с',
  'quantityLAN' : '1 шт',
  'controllerLAN' : 'Realtek 8111G',
  'slotsPCIE1x' : '2 шт',
  'slotsPCIE16x' : '1 шт',
  'supportExpress' : '3.0',
  'supportCrossFire' : '-',
  'USB2' : '4 шт',
  'USB3' : '2 шт',
  'PS2' : '2 шт',
  'coolerPower' : '3 шт',
};
console.log(JSON.stringify(datam3));